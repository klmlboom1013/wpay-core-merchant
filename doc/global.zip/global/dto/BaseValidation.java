package com.wpay.core.merchant.global.dto;

public interface BaseValidation {
    void validateSelf();
}
