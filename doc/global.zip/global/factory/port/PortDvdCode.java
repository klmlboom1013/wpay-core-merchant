package com.wpay.core.merchant.global.factory.port;

public enum PortDvdCode {
    persistence, external, usecase
}
